<?php

    namespace App;

    interface ControllerInterface{

        public function index();
    }